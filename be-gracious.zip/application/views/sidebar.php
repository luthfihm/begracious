<div class="row-fluid">
        
        <!-- =========  SIDE NAVBAR  ====== -->
        <!-- side navbar -->
        <div class="span2">
          <div class="category sidebar-nav">
            <ul class="nav nav-list">
              <?php for($i=1;$i<=6;$i++){ ?>
              <li> <a href="#">TEST#<?php echo $i; ?></a> </li>
              <?php } ?>
            </ul>
          </div><!--category -->
          <div class="category2 sidebar-nav">
            <ul class="nav nav-list">
              <li>SALE </li>
            </ul>
          </div>
          <!--<div class="category2 sidebar-nav">
            <ul class="nav nav-list">
              <li>E-GIFT CARD </li>
            </ul>
          </div>-->
      </div><!--/sidenavbar-->