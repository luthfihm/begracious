<div class="span10">
  <div class="pagination pagination-mini">
        <ul>
          <li><a href="<?php echo base_url(); ?>">Home</a></li>
          <li class="on"><a href="<?php echo base_url('page/track'); ?>">Tracking Order</a></li>
        </ul>
      </div>
  <div class="row-fluid">
    <h4> Tracking Order</h4>
    <div class="span6">
      <ul class="unstyled">
        <li> Your ID Order 
          <form action="<?php echo base_url('page/tracking'); ?>" method="post">
            <input type="text" class="search-query" placeholder="Type Your ID Order Here" name="order_id">
            <input type="submit" style="background:url('<?php echo base_url('assets/img/go_2.png'); ?>') no-repeat 50%;width:50px;height:50px;" value="">
          </form></li>
    </ul>
    </div>
  </div>
     
  <div class="row-fluid">
    <?php if ($order != NULL){ ?>
    <div class="span7">
     
       <div class="pesan">
        <div class="row-fluid">
          <div class="span5 offset1"><h4>Order ID</h4></div>
          <div class="span6"><h4>: <?php echo $order->order_id; ?></h4></div>
        </div>
        <div class="row-fluid">
          <div class="span5 offset1"><h4>Total Order</h4></div>
          <div class="span6"><h4>: IDR <?php echo $order->total; ?></h4></div>
        </div>
        <div class="row-fluid">
          <div class="span5 offset1"><h4>Order Status</h4></div>
          <?php 
            if ($order->status == 0)
            {
              $status = "Belum Bayar";
            }
            else if ($order->status == 1)
            {
              $status = "Sudah Bayar";
            }
            else if ($order->status == 2)
            {
              $status = "Sudah Dikirim";
            }
           ?>
          <div class="span6"><h4>: <?php echo $status; ?></h4></div>
        </div>
       </div>
        <?php 
          $user = $this->user_model->get_user_by_id($order->id_user);
          $orderline = $this->order_model->Detail($order->order_id);
         ?>
         <br>
         <br>
       <table>
         <tr>
           <td>Email Address</td>
           <td>: <?php echo $user->username; ?></td>
         </tr>
         <tr>
           <td>Nama Lengkap</td>
           <td>: <?php echo $user->nama; ?></td>
         </tr>
         <tr>
           <td>Nomor HP</td>
           <td>: <?php echo $user->no_hp; ?></td>
         </tr>
         <tr>
           <td>Alamat</td>
           <td>: <?php echo $user->alamat; ?></td>
         </tr>
         <tr>
           <td>Kota</td>
           <td>: <?php echo $user->kota; ?></td>
         </tr>
         <tr>
           <td>Kode Pos</td>
           <td>: <?php echo $user->kode_pos; ?></td>
         </tr>
       </table>
       
       <br><br>
    </div>
    <div class="span5">
      
    </div>
      <table class="table">
         <thead>
           <tr>
             <th colspan="2">Description</th>
             <th width="75px">Size</th>
             <th width="75px">Quantity</th>
             <th width="130px">Price</th>
           </tr>
         </thead>
         <tbody>
           <?php 
            foreach ($orderline as $row){
            $barang = $this->barang_model->get_by_id($row->id_barang); 
            $img = explode(';',$barang->gambar);
            ?>
           <tr>
             <td width="160px"><img src="<?php echo $img[0]; ?>" width="150px" alt=""></td>
             <td><?php echo $barang->nama; ?></td>
             <td><?php echo $row->ukuran; ?></td>
             <td><?php echo $row->quantity; ?></td>
             <td><?php echo $barang->harga*$row->quantity; ?></td>
           </tr>
           <?php } ?>
         </tbody>
         <thead>
           <tr>
             <th colspan="3"></th>
             <th colspan="2">
               <div>
                 <table>
                   <tr>
                     <td>SUBTOTAL</td>
                     <td>: IDR <?php echo $order->subtotal;  ?></td>
                   </tr>
                   <tr>
                     <td>DISKON</td>
                     <td>: IDR <?php echo $order->diskon;  ?></td>
                   </tr>
                   <tr>
                     <td>ONGKIR</td>
                     <td>: IDR <?php echo $order->ongkir;  ?></td>
                   </tr>
                   <tr>
                     <td>GRAND TOTAL</td>
                     <td>: IDR <?php echo $order->total;  ?></td>
                   </tr>
                 </table>
               </div>
             </th>
           </tr>
         </thead>
       </table>
      <?php }else{ ?>
      <div class="span7">
        <h4>Not Found.</h4>
      </div>
      <?php } ?>
  </div>
</div>