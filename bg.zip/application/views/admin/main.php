<div class="container">
	<div class="row">
		<div class="col-md-8">
			<table class="table table-row">
				<thead>
					<tr>
						<th align="center" colspan="2">Home Slideshow</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($slide as $row){ ?>
					<tr>
						<td>
							<img src="<?php echo $row->img; ?>" alt="" width="300px"><br>
						</td>
						<td>
							<h4>URL : <?php echo $row->url; ?></h4>
							<button class="btn btn-primary" data-toggle="modal" data-target="#modal-edit" onclick="edit_slide('<?php echo $row->id; ?>');">Edit</button>
							<button class="btn btn-warning" onclick="delete_slide('<?php echo $row->id; ?>');">Delete</button>
						</td>
					</tr>
					<?php } ?>
				</tbody>
				<thead>
					<tr>
						<td colspan="2">
							<div align="center">
								<button class="btn btn-primary" data-toggle="modal" data-target="#modal-add">Add</button>
							</div>
						</td>
					</tr>
				</thead>
			</table>
		</div>
	</div>
</div>

<!-- Modal -->
<form id="form-add" class="form-horizontal" role="form">
<div class="modal fade" id="modal-add" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" id="myModalLabel">Add Slideshow</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label for="url" class="col-sm-2 control-label">URL</label>
					<div class="col-sm-10">
						<input type="url" class="form-control" id="url" placeholder="URL">
					</div>
				</div>
				<div class="form-group">
					<label for="img" class="col-sm-2 control-label">Image</label>
					<div class="col-sm-10">
						<div class="input-group">
						    <input type="text" id="img" name="img" class="form-control" placeholder="Image URL">
						    <span class="input-group-btn">
						    	<a href="<?php echo base_url('filemanager/dialog.php?type=1&field_id=img'); ?>" class="btn btn-default iframe-btn" type="button"><span class="glyphicon glyphicon-folder-open"></span></a>
						    </span>
					    </div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<div id="btn-submit">
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
				<div class="row" id="loading" style="display:none;">
					<div class="col-xs-4 col-xs-offset-8">
						<div class="alert alert-warning" align="left">Loading...</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</form>

<form id="form-edit" class="form-horizontal" role="form">
<div class="modal fade" id="modal-edit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content" id="content-edit" style="display:none;">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title" id="myModalLabel">Edit Slideshow</h4>
			</div>
			<div class="modal-body">
				<input type="hidden" id="edit-id">
				<div class="form-group">
					<label for="edit-url" class="col-sm-2 control-label">URL</label>
					<div class="col-sm-10">
						<input type="url" class="form-control" id="edit-url" placeholder="URL">
					</div>
				</div>
				<div class="form-group">
					<label for="img" class="col-sm-2 control-label">Image</label>
					<div class="col-sm-10">
						<div class="input-group">
						    <input type="text" id="edit-img" name="edit-img" class="form-control" placeholder="Image URL">
						    <span class="input-group-btn">
						    	<a href="<?php echo base_url('filemanager/dialog.php?type=1&field_id=edit-img'); ?>" class="btn btn-default iframe-btn" type="button"><span class="glyphicon glyphicon-folder-open"></span></a>
						    </span>
					    </div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<div id="edit-btn-submit">
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
				<div class="row" id="edit-loading" style="display:none;">
					<div class="col-xs-4 col-xs-offset-8">
						<div class="alert alert-warning" align="left">Loading...</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</form>
<script>
	$(document).ready(function(){
		$("#form-add").submit(function(){
			if (($("#url").val() != "")&&
				($("#img").val() != ""))
			{
				$.ajax({
					type 		: "POST",
					url 		: "<?php echo base_url('ajax/add_slide'); ?>",
					data 		: {
						url : $("#url").val(),
						img : $("#img").val()
					},
					success 	: function(html){
						if (html == "true")
						{
							window.location = location.href;
						}
						else
						{
							$("#btn-submit").css("display","block");
							$("#loading").css("display","none");
							alert("Gagal");
						}
					},
					beforeSend 	: function(){
						$("#btn-submit").css("display","none");
						$("#loading").css("display","block");
					}
				});
			}
			else
			{
				alert("Isian belum lengkap!");
			}
			return false;
		});
		$("#form-edit").submit(function(){
			if (($("#edit-url").val() != "")&&
				($("#edit-img").val() != ""))
			{
				$.ajax({
					type 		: "POST",
					url 		: "<?php echo base_url('ajax/edit_slide'); ?>",
					data 		: {
						id  : $("#edit-id").val(),
						url : $("#edit-url").val(),
						img : $("#edit-img").val()
					},
					success 	: function(html){
						if (html == "true")
						{
							window.location = location.href;
						}
						else
						{
							$("#edit-btn-submit").css("display","block");
							$("#edit-loading").css("display","none");
							alert("Gagal");
						}
					},
					beforeSend 	: function(){
						$("#edit-btn-submit").css("display","none");
						$("#edit-loading").css("display","block");
					}
				});
			}
			else
			{
				alert("Isian belum lengkap!");
			}
			return false;
		});
	});

	function delete_slide(id_slide)
	{
		if (confirm("Yakin untuk menghapus?"))
		{
			$.ajax({

				type	: "POST",

				url 	: "<?php echo base_url('ajax/delete_slide'); ?>",

				data	: {

					id : id_slide

				},

				success	: function(html){

					if (html == 'true'){

						window.location = location.href;

					}

				},

				beforeSend : function(){

					

				}

			});
		}
	}

	function edit_slide(id_slide)
	{
		$.ajax({
            url: "<?php echo base_url('ajax/get_edit_slide'); ?>/"+id_slide,
            dataType: "json",
            success: function( data ){
				$("#edit-id").val(data['id']);
				$("#edit-url").val(data['url']);
				$("#edit-img").val(data['img']);
				$("#content-edit").show();
			}
		});
	}
</script>