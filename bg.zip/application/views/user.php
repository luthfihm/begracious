

        <div class="span10">

          <div class="pagination pagination-mini">

                <ul>

                  <li><a href="<?php echo base_url(); ?>">Home</a></li>

                  <li class="on"><a href="<?php echo base_url('page/user'); ?>">Account</a></li>

                </ul>

              </div>

          <div class="row-fluid">



            <h4> Edit Account</h4>

          <div class="span6">

            <form id="form-register">

            <ul class="unstyled">

              <li>Email Address <br><input id="email" type="text" placeholder="Type here" value="<?php echo $user->username; ?>"></li>              

              <li>Full Name <br><input id="nama" type="text" placeholder="Type here" value="<?php echo $user->nama; ?>"></li>

              <li>Password <br><input id="pass1" type="password" placeholder="Type here"></li>

              <li>Re-Type Password <br><input id="pass2" type="password" placeholder="Type here"></li>

            </ul>

            <input type="submit" value="Save">

          </div>

          <div class="span4">

            <ul class="unstyled"> 

              <li>Address<br> <input id="alamat" type="text" placeholder="Type here" value="<?php echo $user->alamat; ?>"></li> 

              <li>City<br> <input id="city" type="text" placeholder="Type here" value="<?php echo $user->kota; ?>"></li> 

              <li>Postal Code <br><input id="kode_pos" type="text" placeholder="Type here" value="<?php echo $user->kode_pos; ?>"></li>

              <li>Mobile Phone <br><input id="no_hp" type="text" placeholder="Type here" value="<?php echo $user->no_hp; ?>"></li>

            </ul>

            </form>

          </div>

          </div>



            <script>

              $(document).ready(function() {

                $("#city").autocomplete({

                  source: function( request, response ) {

                    $.ajax({

                      url: "<?php echo base_url('ajax/list_city'); ?>/"+request.term,

                      dataType: "json",

                      success: function( data ) {

                        response($.map(data, function (value, key) {

                            return {

                                label: value,

                                value: value

                            };

                        }));

                      }

                    });

                  },

                });

                $("#form-register").submit(function(){

                  if (($("#email").val() != "")&&

                      ($("#nama").val() != "")&&

                      ($("#pass1").val() != "")&&

                      ($("#pass2").val() == $("#pass1").val())&&

                      ($("#alamat").val() != "")&&

                      ($("#city").val() != "")&&

                      ($("#kode_pos").val() != "")&&

                      ($("#no_hp").val() != ""))

                  {

                      $.ajax({

                      type    : "POST",

                      url     : "<?php echo base_url('ajax/edit_user') ?>",

                      data    : {

                        id_user    : "<?php echo $user->id_user; ?>",

                        username   : $("#email").val(),

                        nama       : $("#nama").val(),

                        password   : $("#pass1").val(),

                        alamat     : $("#alamat").val(),

                        kota       : $("#city").val(),

                        kode_pos   : $("#kode_pos").val(),

                        no_hp      : $("#no_hp").val()

                      },

                      success : function(html){

                        if (html == "true"){


                          window.location = location.href;

                        }else{

                          alert("Edit Gagal!");

                        }

                      }

                    });

                  }else{

                    alert("Data belum lengkap!");

                  }

                  return false;

                })

              });

            </script>