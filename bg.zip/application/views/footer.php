

       
        


        <!-- ========  BOTTOM NAV ======= -->
        <div class="bottomnav">
          <div class="row-fluid">
            <div class="span4"><hr>
            </div>
            <div class="span4">
              <ul class="unstyled sosmed">
                <li><a href=""><img src="<?php echo base_url(); ?>
assets/img/iconmonstr-instagram-6-icon-24.png" height="30px" width="30px"></a></li>
                <li><a href=""><img src="<?php echo base_url(); ?>
assets/img/iconmonstr-facebook-3-icon-24.png" height="30px" width="30px"></a></li>
                <li><a href=""><img src="<?php echo base_url(); ?>
assets/img/iconmonstr-twitter-3-icon-24.png" height="30px" width="30px"></a></li>
                <li><a href=""><img src="<?php echo base_url(); ?>
assets/img/iconmonstr-blogger-icon-24.png" height="30px" width="30px"></a></li>
                <li><a href=""><img src="<?php echo base_url(); ?>
assets/img/iconmonstr-youtube-icon-24.png" height="30px" width="30px"></a></li>
                <li><a href=""><img src="<?php echo base_url(); ?>
assets/img/iconmonstr-shopping-cart-3-icon-24.png" height="30px" width="30px"></a></li>
              </ul>
            </div>
            <div class="span4"><hr>
            </div>
          </div>
          <div class="row-fluid">
            <div class="span5">
              <ul class="unstyled">
                <li class="nav-header">ORDER</li>
                <li class="nav-bot">Payment Confirmation</li>
                <li class="nav-bot">Tracking Order</li>
                <li class="nav-bot">How to Order</li>
              </ul>
            </div>
          <div class="span4">
              <ul class="unstyled">
                <li class="nav-header">PAYMENT</li>
                <li class="nav-bot"><a href=""><img src="<?php echo base_url(); ?>
assets/img/bca_bw.png" height="20px" width="60px"></a> <a href=""><img src="<?php echo base_url(); ?>
assets/img/bni_bw.png" height="20px" width="60px"></a> <a href=""><img src="<?php echo base_url(); ?>
assets/img/mandiri_bw.png" height="20px" width="60px"></a><a href=""><img src="<?php echo base_url(); ?>
assets/img/paypal_bw.png" height="20px" width="60px"></a></li>
              </ul>
            </div>
          <div class="span3">
              <ul class="unstyled">
                <li class="nav-header">SHIPPING</li>
                <li class="nav-bot"><a href=""><img src="<?php echo base_url(); ?>
assets/img/jne_bw.png" height="20px" width="60px"></a> <a href=""><img src="<?php echo base_url(); ?>
assets/img/tiki_bw.png" height="40px" width="60px"></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <footer>
          <p class="pull-right"><a href="#">Back to top</a></p>
          <p>&copy; BE GRACIOUS 2014-2017. All Rights Reserved. <a href="#">Privacy & Terms of Use</a></p>
        </footer>
        

        </div> 




      </div>
  

  </div> <!--body -->
    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo base_url(); ?>
assets/js/jquery.js"></script>
    <script src="<?php echo base_url(); ?>
assets/js/bootstrap-transition.js"></script>
    <script src="<?php echo base_url(); ?>
assets/js/bootstrap-alert.js"></script>
    <script src="<?php echo base_url(); ?>
assets/js/bootstrap-modal.js"></script>
    <script src="<?php echo base_url(); ?>
assets/js/bootstrap-dropdown.js"></script>
    <script src="<?php echo base_url(); ?>
assets/js/bootstrap-scrollspy.js"></script>
    <script src="<?php echo base_url(); ?>
assets/js/bootstrap-tab.js"></script>
    <script src="<?php echo base_url(); ?>
assets/js/bootstrap-tooltip.js"></script>
    <script src="<?php echo base_url(); ?>
assets/js/bootstrap-popover.js"></script>
    <script src="<?php echo base_url(); ?>
assets/js/bootstrap-button.js"></script>
    <script src="<?php echo base_url(); ?>
assets/js/bootstrap-collapse.js"></script>
    <script src="<?php echo base_url(); ?>
assets/js/bootstrap-carousel.js"></script>
    <script src="<?php echo base_url(); ?>
assets/js/bootstrap-typeahead.js"></script>

  </body>
</html>