
<div class="span10">
  

  <!-- Carousel
  ================================================== -->
  <div id="myCarousel" class="carousel slide">
    <div class="carousel-inner">
      <?php $i=1; foreach ($slide as $row){ ?>
      <div class="item<?php if ($i == 1) echo ' active'; ?>">
        <a href="<?php echo $row->url; ?>"><img src="<?php echo $row->img; ?>" alt=""></a>
      </div>
      <?php $i++;} ?>
    </div>
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">&lsaquo;</a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">&rsaquo;</a>
  </div><!-- /.carousel -->


<!-- =============  CONTENT  ======== -->
<div class="navcontent" id="content">
  <div class="row-fluid">
    <div class="span5">
    <ul class="breadcrumb">
      <?php if (($kat != 'all')&&($kat != 'sale')) $num = $this->barang_model->jumlah_kat($kat); ?>
      <li><a href="#">Showing Item <?php echo ($page-1)*20+1; ?> - <?php if (($page*20) < $num) echo ($page*20); else echo $num; ?> of <?php echo $num; ?></a> <span class="divider">&middot;</span></li>
      <li>CATEGORY: <?php if (($kat == 'all')||($kat == 'sale')) echo 'All'; else echo $this->kategori_model->get_kategori($kat); ?> </li>
    </ul>
    </div>
    <?php 
      if ($kat == 'all')
        $string = base_url('page/search').'/'.$match.'/';
      else
        $string = base_url('page/kategori').'/'.$kat.'/';
     ?>
    <?php if ($sort != 0) $s = "?sort=".$sort; else $s = ""; ?>
    <div class="span3">
      <div class="pagination pagination-mini">
        <ul>
          <li><a href="<?php if ($prev) echo $string.($page-1).$s; else echo '#'; ?>">Prev</a></li>
          <?php if ($prev && !$next){ ?>
          <li><a href="<?php echo $string.($page-1).$s; ?>"><?php echo ($page-1); ?></a></li>
          <?php } ?>
          <li><a href="<?php echo $string.$page.$s; ?>"><?php echo $page; ?></a></li>
          <?php if ($next){ ?>
          <li><a href="<?php echo $string.($page+1).$s; ?>"><?php echo ($page+1); ?></a></li>
          <?php } ?>
          <li><a href="<?php if ($next) echo $string.($page+1).$s; else echo '#'; ?>">Next</a></li>
        </ul>
      </div>
    </div>
    <?php 
      if ($sort == 0)
        $type = "Default";
      else if ($sort == 1)
        $type = "Name A to Z";
      else if ($sort == 2)
        $type = "Name Z to A";
      else if ($sort == 3)
        $type = "Price High to Low";
      else if ($sort == 4)
        $type = "Price Low to High";
     ?>
    <div class="span3">
      <div class="btn-group pull-right">
        <button class="btn btn-mini dropdown-toggle" data-toggle="dropdown">Sort By : <?php echo $type; ?></button>
        <ul class="dropdown-menu">
          <li><a href="<?php echo $string.$page; ?>">Default</a></li>
          <li><a href="<?php echo $string.$page.'?sort=1'; ?>">Name A to Z</a></li>
          <li><a href="<?php echo $string.$page.'?sort=2'; ?>">Name Z to A</a></li>
          <li><a href="<?php echo $string.$page.'?sort=3'; ?>">Price High to Low</a></li>
          <li><a href="<?php echo $string.$page.'?sort=4'; ?>">Price Low to High</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>

<div class="gallery">
  <?php 
  foreach ($list_barang as $row){ 
  $img = explode(";",$row->gambar);
    ?>
  <div class="galitem">
    <a href="<?php echo base_url('page/item').'/'.$row->id; ?>"><img src="<?php echo $img[0]; ?>"></a>
    <div class="desc">
      <b class="name"><?php echo $row->nama; ?></b><br> <b class="price">IDR <?php if ($row->harga_diskon > 0) echo number_format($row->harga-$row->harga_diskon,0,'','.');  else echo number_format($row->harga,0,'','.'); ?></b><?php if ($row->harga_diskon > 0) { ?><span class="pull-right price" style="text-decoration:line-through;">IDR <?php echo number_format($row->harga,0,'','.'); ?></span><?php } ?>
    </div>
  </div>
  <?php } ?>
</div> <!--gallery-->

<div class="navcontent">
  <div class="row-fluid">
    <div class="span5">
    <ul class="breadcrumb">
      
      <li><a href="#">Showing Item <?php echo ($page-1)*20+1; ?> - <?php if (($page*20) < $num) echo ($page*20); else echo $num; ?> of <?php echo $num; ?></a> <span class="divider">&middot;</span></li>
      <li>CATEGORY: <?php if (($kat == 'all')||($kat == 'sale')) echo 'All'; else echo $this->kategori_model->get_kategori($kat); ?> </li>
    </ul>
    </div>
    
    <div class="span3">
      <div class="pagination pagination-mini">
        <ul>
          <li><a href="<?php if ($prev) echo $string.($page-1).$s; else echo '#'; ?>">Prev</a></li>
          <?php if ($prev && !$next){ ?>
          <li><a href="<?php echo $string.($page-1).$s; ?>"><?php echo ($page-1); ?></a></li>
          <?php } ?>
          <li><a href="<?php echo $string.$page.$s; ?>"><?php echo $page; ?></a></li>
          <?php if ($next){ ?>
          <li><a href="<?php echo $string.($page+1).$s; ?>"><?php echo ($page+1); ?></a></li>
          <?php } ?>
          <li><a href="<?php if ($next) echo $string.($page+1).$s; else echo '#'; ?>">Next</a></li>
        </ul>
      </div>
    </div>

    <div class="span3">
      <div class="btn-group pull-right">
        <button class="btn btn-mini dropdown-toggle" data-toggle="dropdown">Sort By : <?php echo $type; ?></button>
        <ul class="dropdown-menu">
          <li><a href="<?php echo $string.$page; ?>">Default</a></li>
          <li><a href="<?php echo $string.$page.'?sort=1'; ?>">Name A to Z</a></li>
          <li><a href="<?php echo $string.$page.'?sort=2'; ?>">Name Z to A</a></li>
          <li><a href="<?php echo $string.$page.'?sort=3'; ?>">Price High to Low</a></li>
          <li><a href="<?php echo $string.$page.'?sort=4'; ?>">Price Low to High</a></li>
        </ul>
      </div>
    </div>
  </div>
<!-- Content -->