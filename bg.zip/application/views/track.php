<div class="span10">
  <div class="pagination pagination-mini">
        <ul>
          <li><a href="<?php echo base_url(); ?>">Home</a></li>
          <li class="on"><a href="<?php echo base_url('page/track'); ?>">Tracking Order</a></li>
        </ul>
      </div>
  <div class="row-fluid">
    <h4> Tracking Order</h4>
    <div class="span6">
      <ul class="unstyled">
        <li> Your ID Order 
          <form action="<?php echo base_url('page/tracking'); ?>" method="post">
            <input type="text" class="search-query" placeholder="Type Your ID Order Here" name="order_id">
            <input type="submit" style="background:url('<?php echo base_url('assets/img/go_2.png'); ?>') no-repeat 50%;width:50px;height:50px;" value="">
          </form></li>
    </ul>
    </div>
  </div>
</div>