<?php 

	class Barang_model extends CI_Model {

		function add_barang ($data){

			$query = $this->db->insert('barang',$data);

			return $query;

		}

		function get_by_id ($id){

			$this->db->where('id',$id);

			$query = $this->db->get('barang');

			return $query->row();

		}

		function get_hot()
		{
			$this->db->where('isfeatured', 1);
			$query = $this->db->get('barang');
			return $query->result();
		}

		function get_sale($limit,$offset,$sort)
		{
			$this->db->where('harga_diskon >',0);
			if ($sort == 0)
				$this->db->order_by("id","desc");
			else if ($sort == 1)
				$this->db->order_by("nama","asc");
			else if ($sort == 2)
				$this->db->order_by("nama","desc");
			else if ($sort == 3)
				$this->db->order_by("harga","desc");
			else if ($sort == 4)
				$this->db->order_by("harga","asc");
			$query = $this->db->get('barang', $limit, $offset);
			return $query;
		}

		function jumlah_sale()
		{
			$this->db->where('harga_diskon >',0);
			$query = $this->db->get('barang');
			return $query->num_rows();
		}

		function search($match,$limit,$offset,$sort)
		{
			$this->db->like('nama',$match);
			if ($sort == 0)
				$this->db->order_by("id","desc");
			else if ($sort == 1)
				$this->db->order_by("nama","asc");
			else if ($sort == 2)
				$this->db->order_by("nama","desc");
			else if ($sort == 3)
				$this->db->order_by("harga","desc");
			else if ($sort == 4)
				$this->db->order_by("harga","asc");
			$query = $this->db->get('barang', $limit, $offset);
			return $query;
		}

		function search_num($match)
		{
			$this->db->like('nama',$match);
			$query = $this->db->get('barang');
			return $query->num_rows();
		}

		function get_prev ($id){

			$query = $this->db->query("SELECT * FROM barang WHERE id<$id ORDER BY id DESC LIMIT 0,1");

			$query->row()->id;

		}

		function get_by_kat ($kat,$lim,$offset,$sort){

			$this->db->limit($lim,$offset);
			if ($sort == 0)
				$this->db->order_by("id","desc");
			else if ($sort == 1)
				$this->db->order_by("nama","asc");
			else if ($sort == 2)
				$this->db->order_by("nama","desc");
			else if ($sort == 3)
				$this->db->order_by("harga","desc");
			else if ($sort == 4)
				$this->db->order_by("harga","asc");
			$this->db->where('kategori',$kat);

			$query = $this->db->get('barang');

			return $query;

		}

		function get_all ($lim,$offset,$sort){

			$this->db->limit($lim,$offset);
			if ($sort == 0)
				$this->db->order_by("id","desc");
			else if ($sort == 1)
				$this->db->order_by("nama","asc");
			else if ($sort == 2)
				$this->db->order_by("nama","desc");
			else if ($sort == 3)
				$this->db->order_by("harga","desc");
			else if ($sort == 4)
				$this->db->order_by("harga","asc");
			$query = $this->db->get('barang');

			return $query;

		}

		function jumlah()
		{
			$query = $this->db->get('barang');

			return $query->num_rows();
		}

		function jumlah_kat($kat)
		{
			$this->db->where('kategori',$kat);
			$query = $this->db->get('barang');
			return $query->num_rows();
		}

		function update ($id,$data){

			$this->db->where('id',$id);

			$query = $this->db->update('barang',$data);

			return $query;

		}

		function delete ($id){

			$query = $this->db->delete('barang',array('id' => $id));

			return $query;

		}

	}

 ?>