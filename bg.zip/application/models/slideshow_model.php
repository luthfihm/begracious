<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Slideshow_model extends CI_Model {

	function Add($data)
	{
		$query = $this->db->insert('slideshow', $data);
		return $query;
	}

	function GetAll()
	{
		$query = $this->db->get('slideshow');
		return $query->result();
	}

	function Get($id)
	{
		$this->db->where('id', $id);
		$query = $this->db->get('slideshow');
		return $query->row();
	}	

	function Edit($id,$data)
	{
		$this->db->where('id', $id);
		$query = $this->db->update('slideshow', $data);
		return $query;
	}

	function Del($id)
	{
		$this->db->where('id', $id);
		$query = $this->db->delete('slideshow');
		return $query;
	}

}

/* End of file slideshow_model.php */
 ?>