<?php 
	 if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	
	class Ongkir_model extends CI_Model {
	
		function GetCity($query)
		{
		
			$url = 'http://api.ongkir.info/city/list';
			
			$myvars = "API-Key=1323142e311d28bb7a001206204116e1";
			$myvars .= "&origincity=Bandung";
			$myvars .= "&query=".$query;
			$myvars .= "&type=origin";
			$myvars .= "&courier=jne";
			$myvars .= "&format=json";
			$ch = curl_init( $url );
			curl_setopt( $ch, CURLOPT_POST, 1);
			curl_setopt( $ch, CURLOPT_POSTFIELDS, $myvars);
			curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt( $ch, CURLOPT_HEADER, 0);
			curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);
			$response = json_decode(curl_exec($ch));
			if ($response->status->code == 0)
				$list_city = array_unique($response->cities);
			else
				$list_city = array(0 => 'not');
			return $list_city;
		}
		
		function GetOngkir($city,$weight,$service)
		{
			
		    $url = 'http://api.ongkir.info/cost/find';

		    $myvars = "API-Key=1323142e311d28bb7a001206204116e1";
		    $myvars .= "&from=Bandung";
		    $myvars .= "&to=".$city;
		    $myvars .= "&weight=".$weight;
		    $myvars .= "&courier=jne";
		    $myvars .= "&format=json";
		    $ch = curl_init( $url );
		    curl_setopt( $ch, CURLOPT_POST, 1);
		    curl_setopt( $ch, CURLOPT_POSTFIELDS, $myvars);
		    curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
		    curl_setopt( $ch, CURLOPT_HEADER, 0);
		    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);
		    $response = json_decode(curl_exec($ch));
		    if ($response->status->code == 0)
		    {
		    	$hasil = 0;
		    	foreach ($response->price as $price)
		    	{
		    		if ($price->service == $service)
		    		{
		    			$hasil = $price->value;
		    		}
		    	}
		    	return $hasil;
		    }
		    else
		    {
		    	return 0;
		    }
		}
	}
	
	/* End of file ongkir_model.php */
	/* Location: ./application/models/ongkir_model.php */
 ?>